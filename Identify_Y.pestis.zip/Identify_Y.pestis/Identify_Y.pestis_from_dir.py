## Making a dictionary of every specific tags of Yersinia pestis
TagFile = open("Ypestis_Tag97.txt",'r')

mydict={}
for line in TagFile:
    line = line.strip()
    site,tag=line.split("\t")
    tagR = ''
    for base in reversed(tag):
        tagR += base
    table = tagR.maketrans("[]ATGC","][TACG")
    tagRC = tagR.translate(table)
    mydict[site] =[tag,tagRC]
    
TagFile.close()

##Putting the genome of the sample to be tested into the tryFna folder and starting the identification
import os
import re

mydir="./tryFna/"
myout = open("Result_Identify_Ypestis.txt",'w')
myout.write("StrainName\tTags\tIs_Ypestis\n")


for root,dirs,files in os.walk(mydir):
    for file in files:
        myout.write(file+"\t")
        seq=''
        infile = open(os.path.join(root,file),'r')
        for line in infile:
            line = line.strip()
            if not line.startswith(">"):
                seq += line
        
        myMatch=0
        for Site,Tags in mydict.items():
            [tag,tagRC] =Tags
            if re.search(tag,seq) or re.search(tagRC,seq):
                myMatch +=1
        
        result="No"
        if myMatch >=1:
            result="Yes"
        
        myout.write(str(myMatch)+"\t"+result+"\n")
myout.close()

